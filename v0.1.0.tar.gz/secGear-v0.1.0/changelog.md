## release v0.1.0
        Initialize secGear： surport Intel sgx and Arm trustzone(iTrustee OS)
        Libraries: enclave unified lifecycle management APIs, enclave seal data APIs.
        Tools: support codegener/signtools